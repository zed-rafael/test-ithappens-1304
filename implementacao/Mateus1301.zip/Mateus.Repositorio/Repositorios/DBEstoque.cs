﻿using Mateus.Enumerados;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mateus.Repositorio.Repositorios
{
    public class DBEstoque
    {
        public bool ExisteProdutoNaFilial(int produtoID, int filialID) 
        {
            DBMySQL db = new DBMySQL();
            db.SQL = "SELECT COUNT(*) FROM MateusEstoque WHERE ProdutoID=@ProdutoID AND FilialID=@FilialID";
            db.AdicionarParametroInt32("@ProdutoID", produtoID);
            db.AdicionarParametroInt32("@FilialID", filialID);
            return Convert.ToInt32(db.RetornarEscalar()) > 0;
        }
        public int EstoqueDoProdutoNaFilial(int produtoID, int filialID) 
        {
            DBMySQL db = new DBMySQL();
            db.SQL = "SELECT Quantidade FROM MateusEstoque WHERE ProdutoID=@ProdutoID AND FilialID=@FilialID";
            db.AdicionarParametroInt32("@ProdutoID", produtoID);
            db.AdicionarParametroInt32("@FilialID", filialID);
            return Convert.ToInt32(db.RetornarEscalar());
        }

        public int IncluirProdutoNoEstoqueDaFilial(int produtoID, int filialID)
        {
            DBMySQL db = new DBMySQL();
            db.SQL = "INSERT INTO MateusEstoque (ProdutoID, FilialID, Quantidade) FROM Estoque WHERE ProdutoID=@ProdutoID AND FilialID=@FilialID";
            db.AdicionarParametroInt32("@ProdutoID", produtoID);
            db.AdicionarParametroInt32("@FilialID", filialID);
            return Convert.ToInt32(db.RetornarEscalar());
        }

        public TipoResultadoPedidoEstoque AtualizarEstoqueDoProdutoNaFilial(int produtoID, int filialID, 
            int quantidadeItemDoPedido, TipoPedidoEstoque tipoDoPedido)
        {
            try
            {
                bool existeProdutoNaFilial = false;
                int quantidadeProdutoNaFilial = 0;
                //Classe de conexão
                DBMySQL db = new DBMySQL();
                //Verificar no banco se o produto já existe no Estoque da Filial
                db.SQL = "SELECT COUNT(*) FROM MateusEstoque WHERE ProdutoID=@ProdutoID AND FilialID=@FilialID";
                db.AdicionarParametroInt32("@ProdutoID", produtoID);
                db.AdicionarParametroInt32("@FilialID", filialID);
                existeProdutoNaFilial = ((int)db.RetornarEscalar() > 0);

                if (existeProdutoNaFilial)
                {
                    //Se ele existir obtém-se a quantidade dele no estoque da Filial
                    db.SQL = "SELECT Quantidade FROM MateusEstoque WHERE ProdutoID=@ProdutoID AND FilialID=@FilialID";
                    db.AdicionarParametroInt32("@ProdutoID", produtoID);
                    db.AdicionarParametroInt32("@FilialID", filialID);
                    quantidadeProdutoNaFilial = (int)db.RetornarEscalar();

                    if (tipoDoPedido == TipoPedidoEstoque.Entrada)
                    {
                        db.SQL = "UPDATE INTO MateusEstoque SET Quantidade=@Quantidade WHERE ProdutoID=@ProdutoID AND FilialID=@FilialID";
                        db.AdicionarParametroInt32("@ProdutoID", produtoID);
                        db.AdicionarParametroInt32("@FilialID", filialID);
                        db.AdicionarParametroInt32("@Quantidade", (quantidadeItemDoPedido + quantidadeProdutoNaFilial));
                        db.ExecutarSQL();
                        return TipoResultadoPedidoEstoque.ProdutoAdicionadoNoEstoque;
                    }
                    else
                    {
                        if (quantidadeItemDoPedido > quantidadeProdutoNaFilial)
                        {
                            return TipoResultadoPedidoEstoque.EstoqueInsuficiente;
                        }
                        db.SQL = "UPDATE INTO MateusEstoque SET Quantidade=@Quantidade WHERE ProdutoID=@ProdutoID AND FilialID=@FilialID";
                        db.AdicionarParametroInt32("@ProdutoID", produtoID);
                        db.AdicionarParametroInt32("@FilialID", filialID);
                        db.AdicionarParametroInt32("@Quantidade", (quantidadeProdutoNaFilial - quantidadeItemDoPedido));
                        db.ExecutarSQL();
                        return TipoResultadoPedidoEstoque.ProdutoRetiradoDoEstoque;
                    }
                }
                else
                {
                    //Se o produto não existir no estoque da Filial, ele será incluído imdediatamente no 
                    //banco de dados e será retornado a mensagem de estoque insuficiente, pois o Produto ainda não existia
                    //no estoque e quando foi inserido no Estoque a sua quantidade é de 0 unidades
                    db.SQL = "INSERT INTO MateusEstoque (ProdutoID, FilialID, Quantidade) FROM Estoque WHERE ProdutoID=@ProdutoID AND FilialID=@FilialID";
                    db.AdicionarParametroInt32("@ProdutoID", produtoID);
                    db.AdicionarParametroInt32("@FilialID", filialID);
                    db.AdicionarParametroInt32("@Quantidade", 0);
                    Convert.ToInt32(db.RetornarEscalar());
                    return TipoResultadoPedidoEstoque.EstoqueInsuficiente;
                }

            }
            catch (Exception)
            {
                return TipoResultadoPedidoEstoque.ErroAoTentarEfetuarPedido;
            }            
        }
    }
}
