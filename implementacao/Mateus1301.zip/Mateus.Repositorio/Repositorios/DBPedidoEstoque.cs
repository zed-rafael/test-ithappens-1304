﻿using Mateus.Dominios;
using Mateus.Enumerados;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;

namespace Mateus.Repositorio.Repositorios
{
    public class DBPedidoEstoque
    {
        /// <summary>
        /// Método que incluri um novo pedido no banco de dados e retorna o ID
        /// </summary>
        /// <param name="Tipo"></param>
        /// <param name="UsuarioID"></param>
        /// <returns>ID do pedido</returns>
        public int NovoPedido(PedidoEstoque pedidoEstoque) 
        {
            //Ao iniciar um pedido é inserido imediatamente no banco de dados o seu tipo, usuário, status e a data
            DBMySQL db = new DBMySQL();
            db.SQL = "INSERT INTO MateusPedidoEstoque (Tipo, UsuarioID, ClienteID, FilialID, Status, DataPedido, TotalPedido) " + 
                "VALUES (@Tipo, @UsuarioID, @ClienteID, @FilialID, @Status, @DataPedido, @TotalPedido)";
            db.AdicionarParametroInt32("@Tipo", (int)pedidoEstoque.Tipo);
            db.AdicionarParametroInt32("@UsuarioID", pedidoEstoque.Usuario.ID);
            db.AdicionarParametroInt32("@FilialID", pedidoEstoque.Filial.ID);
            db.AdicionarParametroInt32("@ClienteID", pedidoEstoque.Cliente.ID);
            db.AdicionarParametroInt32("@Status", (int)pedidoEstoque.Status);
            db.AdicionarParametroDateTime("@DataPedido", DateTime.Now);
            db.AdicionarParametroDecimal("@TotalPedido", pedidoEstoque.TotalPedido);
            db.ExecutarSQL();
            return (int)db.cmd.LastInsertedId;
        }

        public PedidoEstoque VerPedido(int idPedido)
        {
            PedidoEstoque obj = new PedidoEstoque();
            DBMySQL db = new DBMySQL();
            db.SQL = "SELECT ped.ID, ped.DataPedido, ped.Status as StatusPedido, ped.Tipo, cli.Nome as NomeCliente, fil.Descricao, ped.TotalPedido, fil.ID as FilialID " +
                "FROM MateusPedidoEstoque ped " +
                "INNER JOIN MateusCliente cli ON ped.ClienteID=cli.ID " +
                "INNER JOIN MateusFilial fil ON ped.FilialID=fil.ID WHERE ped.ID=@idPedido";
            db.AdicionarParametroInt32("@idPedido", idPedido);
            MySqlDataReader cursor = db.LeitorCursor();
            if (cursor.Read())
            {
                obj.ID = (int)cursor[0];
                obj.Filial.ID = (int)cursor["FilialID"];
                obj.Filial.Descricao = (string)cursor["Descricao"];
                obj.Cliente.Nome = (string)cursor["NomeCliente"];
                obj.DataPedido = Convert.ToDateTime(cursor["DataPedido"]);
                obj.Status = (StatusPedido)(int)cursor["StatusPedido"];
                obj.Tipo = (TipoPedidoEstoque)(int)cursor["Tipo"];
                obj.TotalPedido = Convert.ToDecimal(cursor["TotalPedido"]);
            }
            cursor.Close();
            return obj;
        }

        public List<PedidoEstoque> ListarUltimos50Pedidos()
        {
            List<PedidoEstoque> listPedidos = new List<PedidoEstoque>();
            DBMySQL db = new DBMySQL();
            db.SQL = "SELECT ped.ID, ped.DataPedido, ped.Status as StatusPedido, ped.Tipo, cli.Nome as NomeCliente, fil.Descricao, ped.TotalPedido " + 
                "FROM MateusPedidoEstoque ped " + 
                "INNER JOIN MateusCliente cli ON ped.ClienteID=cli.ID " + 
                "INNER JOIN MateusFilial fil ON ped.FilialID=fil.ID ORDER BY ped.ID DESC LIMIT 50";
            MySqlDataReader cursor = db.LeitorCursor();
            while (cursor.Read())
            {
                PedidoEstoque obj = new PedidoEstoque();
                obj.ID = (int)cursor[0];
                obj.Filial.Descricao = (string)cursor["Descricao"];
                obj.Cliente.Nome = (string)cursor["NomeCliente"];
                obj.ID = (int)cursor["ID"];
                obj.DataPedido = Convert.ToDateTime(cursor["DataPedido"]);
                obj.Status = (StatusPedido)(int)cursor["StatusPedido"];
                obj.Tipo = (TipoPedidoEstoque)(int)cursor["Tipo"];
                obj.TotalPedido = Convert.ToDecimal(cursor["TotalPedido"]);
                listPedidos.Add(obj);
            }
            cursor.Close();
            return listPedidos;
        }

        public int CancelarPedido(int idPedido)
        {
            //Ao iniciar um pedido é inserido imediatamente no banco de dados o seu tipo, usuário, status e a data
            DBMySQL db = new DBMySQL();
            db.SQL = "UPDATE MateusPedidoEstoque SET Status=@Status WHERE ID=@idPedido";
            db.AdicionarParametroInt32("@idPedido", idPedido);
            db.AdicionarParametroInt32("@Status",(int)StatusPedido.Cancelado);
            return db.ExecutarSQL();
        }

        public int FinalizarPedido(int idPedido, decimal totalPedido, FormaPagamento formaPagamento, string observacaoEntrega)
        {
            //Ao iniciar um pedido é inserido imediatamente no banco de dados o seu tipo, usuário, status e a data
            DBMySQL db = new DBMySQL();
            db.SQL = "UPDATE MateusPedidoEstoque SET TotalPedido=@totalPedido, FormaPagamento=@formaPagamento, " +
                "ObsercacaoEntrega=@ObservacaoEntrega WHERE ID=@idPedido";
            db.AdicionarParametroInt32("@idPedido", idPedido);
            db.AdicionarParametroDecimal("@TotalPedido", totalPedido);
            db.AdicionarParametroInt32("@FormaPagamento", (int)formaPagamento);
            db.AdicionarParametroString("@ObservacaoEntrega", observacaoEntrega);
            return db.ExecutarSQL();
        }

        public void AtualizarPedido()
        {

        }
    }
}
