﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mateus.Repositorio.Repositorios
{
    public class DBCliente
    {
        public List<ItemSelect> ListaBasicaClientes() 
        {
            List<ItemSelect> listClientes = new List<ItemSelect>();
            DBMySQL db = new DBMySQL();
            db.SQL = "SELECT ID, Nome FROM MateusCliente ORDER BY Nome";
            MySqlDataReader cursor = db.LeitorCursor();
            while (cursor.Read())
            {
                ItemSelect obj = new ItemSelect();
                obj.ID = (int)cursor["ID"];
                obj.Descricao = (string)cursor["Nome"];
                listClientes.Add(obj);
            }
            cursor.Close();
            return listClientes;
        }

    }
}
