﻿using Mateus.Dominios;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;

namespace Mateus.Repositorio.Repositorios
{
    public class DBProduto
    {
        /// <summary>
        /// Método que obtem um único produto do banco de dados
        /// </summary>
        /// <param name="ID">ID do produto</param>
        public Produto VerProduto(int ID)
        {
            Produto produto = new Produto();
            DBMySQL db = new DBMySQL();
            db.SQL = "SELECT ID, Descricao, PrecoVenda, CodigoBarras FROM MateusProduto WHERE ID=@ID";
            db.AdicionarParametroInt32("@ID", ID);
            MySqlDataReader cursor = db.LeitorCursor();
            if (cursor.Read())
            {
                produto.CodigoBarras = (string)cursor["CodigoBarras"];
                produto.Descricao = (string)cursor["Descricao"];
                produto.ID = (int)cursor["ID"];
                produto.PrecoVenda = (decimal)cursor["PrecoVenda"];
            }
            cursor.Close();
            return produto;
        }

        /// <summary>
        /// Método que inclui um produto no banco de dados MySQL "Mateus"
        /// </summary>
        /// <param name="produto">Objeto produto</param>
        public void InserirProduto(Produto produto) 
        {
            DBMySQL db = new DBMySQL();
            db.SQL = "INSERT INTO MateusProduto (CodigoBarras, Descricao, PrecoVenda) VALUES (@CodigoBarras, @Descricao, @PrecoVenda)";
            db.AdicionarParametroString("@CodigoBarras", produto.CodigoBarras);
            db.AdicionarParametroString("@Descricao", produto.Descricao);
            db.AdicionarParametroDecimal("@PrecoVenda", produto.PrecoVenda);
            db.ExecutarSQL();
        }

        public void AtualizarProduto(Produto produto)
        {
            DBMySQL db = new DBMySQL();
            db.SQL = "UPDATE MateusProduto SET CodigoBarras=@CodigoBarras, Descricao=@Descricao, PrecoVenda=@PrecoVenda WHERE ID=@ID";
            db.AdicionarParametroInt32("@ID", produto.ID);
            db.AdicionarParametroString("@CodigoBarras", produto.CodigoBarras);
            db.AdicionarParametroString("@Descricao", produto.Descricao);
            db.AdicionarParametroDecimal("@PrecoVenda", produto.PrecoVenda);
            db.ExecutarSQL();
        }

        public List<Produto> ListarUltimos50Cadastros()
        {
            List<Produto> listProdutos = new List<Produto>();
            DBMySQL db = new DBMySQL();
            db.SQL = "SELECT ID, Descricao, PrecoVenda, CodigoBarras FROM MateusProduto ORDER BY ID DESC LIMIT 50";
            MySqlDataReader cursor = db.LeitorCursor();
            while (cursor.Read()) 
            {
                Produto obj = new Produto();
                obj.CodigoBarras = (string)cursor["CodigoBarras"];
                obj.Descricao = (string)cursor["Descricao"];
                obj.ID = (int)cursor["ID"];
                obj.PrecoVenda = (decimal)cursor["PrecoVenda"];
                listProdutos.Add(obj);
            }
            cursor.Close();
            return listProdutos;
        }

        /// <summary>
        /// Método para localizar um ou mais produtos com base no texto informado
        /// </summary>
        /// <param name="textoInformado">Qualquer texto que poderá ser interpretado como ID, CodigoBarras ou Descricao</param>
        /// <returns></returns>
        public List<Produto> LocalizarProdutos(string busca)
        {
            int idProcurado;
            
            List<Produto> listProdutos = new List<Produto>();
            DBMySQL db = new DBMySQL();
           
            if (int.TryParse(busca, out idProcurado))
            {
                db.SQL = $"SELECT ID, Descricao, PrecoVenda, CodigoBarras FROM MateusProduto WHERE ID=@ID ORDER BY Descricao ASC";
                db.AdicionarParametroInt32("@ID", idProcurado);
            }
            else
            {
                db.SQL = $"SELECT ID, Descricao, PrecoVenda, CodigoBarras FROM MateusProduto " + 
                    $"WHERE Descricao LIKE '%{busca}%' OR CodigoBarras = '{busca}' ORDER BY Descricao ASC";
            }
            
            MySqlDataReader cursor = db.LeitorCursor();
            while (cursor.Read())
            {
                Produto obj = new Produto();
                obj.CodigoBarras = (string)cursor["CodigoBarras"];
                obj.Descricao = (string)cursor["Descricao"];
                obj.ID = (int)cursor["ID"];
                obj.PrecoVenda = (decimal)cursor["PrecoVenda"];
                listProdutos.Add(obj);
            }
            cursor.Close();
            return listProdutos;
        }

        public List<Produto> ListaBasicaProdutos()
        {
            List<Produto> listProdutos = new List<Produto>();
            DBMySQL db = new DBMySQL();
            db.SQL = "SELECT ID, Descricao, PrecoVenda FROM MateusProduto ORDER BY Descricao";
            MySqlDataReader cursor = db.LeitorCursor();
            while (cursor.Read())
            {
                Produto obj = new Produto();
                obj.ID = (int)cursor["ID"];
                obj.Descricao = (string)cursor["Descricao"];
                obj.PrecoVenda = Convert.ToDecimal(cursor["PrecoVenda"]);
                listProdutos.Add(obj);
            }
            cursor.Close();
            return listProdutos;
        }
    }
}
