﻿using Mateus.Dominios;
using Mateus.Enumerados;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mateus.Repositorio.Repositorios
{
    public class DBItemPedido
    {
        public void AdicionarItemPedido(int filialID, int pedidoID, int produtoID,
            int quantidadeItemPedido, decimal valorTotalItem, StatusItemPedido status, TipoPedidoEstoque tipoPedido) 
        {
            try
            {
                DBMySQL db = new DBMySQL();
                db.SQL = "INSERT INTO MateusItemPedido (PedidoID, ProdutoID, Quantidade, ValorTotal, Status) " +
                    "VALUES (@PedidoID, @ProdutoID, @Quantidade, @ValorTotal, @Status)";
                db.AdicionarParametroInt32("@PedidoID", pedidoID);
                db.AdicionarParametroInt32("@ProdutoID", produtoID);
                db.AdicionarParametroInt32("@Quantidade", quantidadeItemPedido);
                db.AdicionarParametroDecimal("@ValorTotal", valorTotalItem);
                db.AdicionarParametroInt32("@Status", (int)status);
                db.ExecutarSQL();

                new DBEstoque().AtualizarEstoqueDoProdutoNaFilial(produtoID, filialID,
                    quantidadeItemPedido, tipoPedido);
            }
            catch (MySql.Data.MySqlClient.MySqlException ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<ItemPedido> ListaItemsDoPedido(int pedidoID)
        {
            List<ItemPedido> listItensPedido = new List<ItemPedido>();
            DBMySQL db = new DBMySQL();
            db.SQL = "SELECT it.ID, prod.Descricao, prod.PrecoVenda, it.Quantidade, it.ValorTotal " +
                "FROM MateusItemPedido it INNER JOIN MateusProduto prod ON it.ProdutoID=prod.ID WHERE it.PedidoID=@PedidoID";
            db.AdicionarParametroInt32("@PedidoID", pedidoID);
            MySqlDataReader cursor = db.LeitorCursor();
            while (cursor.Read())
            {
                ItemPedido obj = new ItemPedido();
                obj.ID = (int)cursor["ID"];
                obj.Produto.Descricao = (string)cursor["Descricao"];
                obj.Produto.PrecoVenda = Convert.ToDecimal(cursor["PrecoVenda"]);
                obj.Quantidade = (int)cursor["Quantidade"];
                obj.ValorTotal = (decimal)cursor["ValorTotal"];
                listItensPedido.Add(obj);
            }
            cursor.Close();
            return listItensPedido;
        }
    }
}
