﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mateus.Repositorio.Repositorios
{
    public class DBFilial
    {
        public List<ItemSelect> ListaBasicaFiliais()
        {
            List<ItemSelect> listFiliais = new List<ItemSelect>();
            DBMySQL db = new DBMySQL();
            db.SQL = "SELECT ID, Descricao FROM MateusFilial ORDER BY Descricao";
            MySqlDataReader cursor = db.LeitorCursor();
            while (cursor.Read())
            {
                ItemSelect obj = new ItemSelect();
                obj.ID = (int)cursor["ID"];
                obj.Descricao = (string)cursor["Descricao"];
                listFiliais.Add(obj);
            }
            cursor.Close();
            return listFiliais;
        }
    }
}
