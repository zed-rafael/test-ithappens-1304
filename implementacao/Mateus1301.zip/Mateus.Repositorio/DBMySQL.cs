﻿using MySql.Data.MySqlClient;
using System;
using System.Data;

namespace Mateus.Repositorio
{
    public class DBMySQL
    {
        //Variáveis da classe
        public MySqlCommand cmd;
        private MySqlConnection Conex;

        public DBMySQL()
        {
            Conex = new MySqlConnection(@"User Id=ztec;Password=cemar2020op642;Host=mysql.ztec.uni5.net;Database=ztec");
            cmd = new MySqlCommand();
            cmd.Connection = Conex;
        }

        private void AbrirConexao()
        {
            try
            {
                if (Conex.State == ConnectionState.Closed)
                    this.Conex.Open();
            }
            catch (MySqlException ex)
            {
                throw new Exception(ex.Message);
            }
            catch (Exception)
            {
                throw new Exception("Sem conexão com a internet!");
            }
        }

        private void FecharConexao()
        {
            if (Conex.State != ConnectionState.Closed)
                Conex.Close();
        }

        public String SQL
        {
            get { return cmd.CommandText; }
            set { cmd.Parameters.Clear(); cmd.CommandText = value; }
        }

        public Int32 ExecutarSQL()
        {
            Int32 RES = 0;
            try
            {
                this.AbrirConexao();
                RES = this.cmd.ExecuteNonQuery();
                this.FecharConexao();
            }
            catch (MySqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally { this.FecharConexao(); }
            return RES;
        }

        public MySqlDataReader LeitorCursor()
        {
            MySqlDataReader R = null;
            try
            {
                this.AbrirConexao();
                R = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                return R;
            }
            catch (MySqlException ex)
            {
                throw new Exception(ex.Message.ToString());
            }
        }

        public Object RetornarEscalar()
        {
            Object RES = null;
            try
            {
                this.AbrirConexao();
                RES = this.cmd.ExecuteScalar();
                this.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally { this.FecharConexao(); }
            return RES;
        }

        public void AdicionarParametroInt32(String NOME, Int32 VALUE)
        {
            MySqlParameter P = new MySqlParameter();
            P.ParameterName = NOME;
            P.Value = VALUE;
            this.cmd.Parameters.Add(P);
        }

        public void AdicionarParametroChar(String NOME, Int32 VALUE)
        {
            MySqlParameter P = new MySqlParameter();
            P.ParameterName = NOME;
            P.Value = (char)VALUE;
            this.cmd.Parameters.Add(P);
        }

        public void AdicionarParametroDateTime(String NOME, DateTime VALUE)
        {
            MySqlParameter P = new MySqlParameter();
            P.IsNullable = true;
            P.ParameterName = NOME;
            if (VALUE.Date < new DateTime(1900, 1, 1))
                P.Value = DBNull.Value;
            else
                P.Value = VALUE;
            this.cmd.Parameters.Add(P);
        }

        public void AdicionarParametroString(String NOME, String VALUE)
        {
            MySqlParameter P = new MySqlParameter();
            P.IsNullable = true;
            P.ParameterName = NOME;
            if (string.IsNullOrEmpty(VALUE))
                P.Value = DBNull.Value;
            else P.Value = VALUE;
            this.cmd.Parameters.Add(P);
        }

        public void AdicionarParametroDecimal(String NOME, Decimal VALUE)
        {
            MySqlParameter P = new MySqlParameter();
            P.IsNullable = true;
            P.ParameterName = NOME;
            P.Value = VALUE;
            this.cmd.Parameters.Add(P);
        }

        public void AdicionarParametroBool(String NOME, Boolean VALUE)
        {
            MySqlParameter P = new MySqlParameter();
            P.IsNullable = true;
            P.ParameterName = NOME;
            P.Value = VALUE;
            this.cmd.Parameters.Add(P);
        }
    }
}
