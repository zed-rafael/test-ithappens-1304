﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Mateus.Interface
{
    public class Carregamento : BackgroundWorker
    {
        Dashboard Main = (Dashboard)Application.OpenForms["Dashboard"];
        TelaCarregamento frmLoad = new TelaCarregamento();
        public Action _PRE_WORK { get; set; }
        public Action _WORK { get; set; }
        public Action _COMPLETED { get; set; }
        public Action _ERROR { get; set; }
        public Action _CLOSE_FORM { get; set; }
        public Form _FORM { get; set; }
        public string _ErrorString { get; set; }

        public void START()
        {
            Dashboard Main = (Dashboard)Application.OpenForms["Dashboard"];
            Main.panelLoad.Visible = true;
            Main.panelLoad.BringToFront();
            //frmLoad.Show();
            if (!this.IsBusy)
                this.RunWorkerAsync();
        }

        public Carregamento()
        {
            _ErrorString = "";
            this.DoWork += ZBworker_DoWork;
            this.RunWorkerCompleted += ZBworker_RunWorkerCompleted;
        }

        private void ZBworker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                _WORK();
                e.Result = "OK";
            }
            catch (Exception ex)
            {
                e.Result = "error";
            }
        }

        private void ZBworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            Main.panelLoad.Hide();
            //frmLoad.Hide();
            if (e.Result.ToString() == "OK")
            {
                if (_COMPLETED != null)
                    _COMPLETED();
            }
            else
            {
                _ERROR();
                if (_FORM != null)
                {
                    _FORM.Close();
                }
            }
        }
    }
}
