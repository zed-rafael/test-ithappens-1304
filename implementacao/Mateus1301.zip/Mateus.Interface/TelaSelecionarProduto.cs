﻿using Mateus.Dominios;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Mateus.Interface
{
    public partial class TelaSelecionarProduto : Form
    {
        public string _TituloJanela { get; set; }
        public List<Produto> _Itens = new List<Produto>();
        public Produto _itemSelecionado { get; set; }
        public TelaSelecionarProduto()
        {
            InitializeComponent();
        }

        private void TelaSelecionarItens_Load(object sender, System.EventArgs e)
        {
            //lblTitulo.Text = _TituloJanela;
            gridItens.Items.Clear();
            gridItens.BeginUpdate();
            foreach (var obj in _Itens)
            {
                ListViewItem itemGrid = new ListViewItem();
                itemGrid.Tag = obj;
                itemGrid.Text = obj.Descricao;
                itemGrid.SubItems.Add(obj.PrecoVenda.ToString("c2"));
                gridItens.Items.Add(itemGrid);
            }
            gridItens.EndUpdate();
        }

        void SelecionarLinha() 
        {
            if (gridItens.SelectedItems.Count > 0) 
            {
                _itemSelecionado = (Produto)gridItens.SelectedItems[0].Tag;
                DialogResult = DialogResult.OK;
            }
        }

        private void gridItens_DoubleClick(object sender, System.EventArgs e)
        {
            SelecionarLinha();
        }
    }
}
