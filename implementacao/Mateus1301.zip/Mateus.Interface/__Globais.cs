﻿using Mateus.Dominios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mateus.Interface
{
    public static class __Globais
    {
        //Variáveis globais
        public static Usuario _Usuario;



        //Metódo para abrir e fechar telas (forms)
        public static void AbrirJanelaNoDashboard(Form frm)
        {
            frm.TopLevel = false;
            Dashboard Main = (Dashboard)Application.OpenForms["Dashboard"];
            if (Main != null)
            {
                frm.Parent = Main.panelMain;
            }
            frm.Show();
        }
    }
}
