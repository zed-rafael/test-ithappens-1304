﻿using System.Windows.Forms;

namespace Mateus.Interface
{
    public partial class TelaBaseListagem : Form
    {
        public TelaBaseListagem()
        {
            InitializeComponent();
        }
    }
}
