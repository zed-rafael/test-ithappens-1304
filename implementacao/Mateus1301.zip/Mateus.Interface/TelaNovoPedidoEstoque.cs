﻿using Mateus.Dominios;
using Mateus.Enumerados;
using Mateus.Repositorio.Repositorios;
using System;
using System.Windows.Forms;

namespace Mateus.Interface
{
    public partial class TelaNovoPedidoEstoque : Form
    {
        public PedidoEstoque _pedidoEstoque { get; set; }
        public TelaNovoPedidoEstoque()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                _pedidoEstoque.Usuario = __Globais._Usuario;
                _pedidoEstoque.Cliente = new Cliente() { ID = (int)txtCliente.Tag, Nome = txtCliente.Text };
                _pedidoEstoque.Filial = new Filial() { ID = (int)txtFilial.Tag, Descricao = txtFilial.Text };
                _pedidoEstoque.Status = StatusPedido.EmAndamento;
                _pedidoEstoque.TotalPedido = decimal.Zero;
                if (rdbEntrada.Checked)
                    _pedidoEstoque.Tipo = TipoPedidoEstoque.Entrada;
                else
                    _pedidoEstoque.Tipo = TipoPedidoEstoque.Saida;

                new DBPedidoEstoque().NovoPedido(_pedidoEstoque);

                TelaPedidoEstoque tela = new TelaPedidoEstoque();
                tela._pedidoEstoque = _pedidoEstoque;
                __Globais.AbrirJanelaNoDashboard(tela);
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao tentar abrir o Pedido de Estoque.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void TelaNovoPedidoEstoque_Load(object sender, EventArgs e)
        {
            _pedidoEstoque = new PedidoEstoque();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSelecionarFilial_Click(object sender, EventArgs e)
        {
            TelaSelecionarItens tela = new TelaSelecionarItens();
            tela._Itens = new DBFilial().ListaBasicaFiliais();
            tela._TituloJanela = "Selecionar filial";
            if (tela.ShowDialog() == DialogResult.OK)
            {
                txtFilial.Text = tela._itemSelecionado.Descricao;
                txtFilial.Tag = tela._itemSelecionado.ID;
            }
        }

        private void btnSelecionarCliente_Click(object sender, EventArgs e)
        {
            TelaSelecionarItens tela = new TelaSelecionarItens();
            tela._Itens = new DBCliente().ListaBasicaClientes();
            tela._TituloJanela = "Selecionar cliente";
            if (tela.ShowDialog() == DialogResult.OK)
            {
                txtCliente.Text = tela._itemSelecionado.Descricao;
                txtCliente.Tag = tela._itemSelecionado.ID;
            }
        }
    }
}
