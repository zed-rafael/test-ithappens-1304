﻿using Mateus.Dominios;
using Mateus.Repositorio.Repositorios;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Mateus.Interface
{
    public partial class TelaProdutos : TelaBaseListagem
    {
        //Coleção (List) que irá armazenar os produtos para serem exibidos no grid
        List<Produto> _listProdutos;
        public TelaProdutos()
        {
            InitializeComponent();
            //Preenche o _listProdutos com os últimos 50 cadastros do banco de dados ao iniciar a exibição da tela
            _listProdutos = new DBProduto().ListarUltimos50Cadastros();
        }

        private void btnInlcuir_Click(object sender, EventArgs e)
        {
            TelaIncluirProduto tela = new TelaIncluirProduto();
            if (tela.ShowDialog() == DialogResult.OK) 
            {
                PreencherControlesDeTela();
            }
        }

        //Chamado quando a tela é carregada
        private void TelaProdutos_Load(object sender, EventArgs e)
        {
            //Preenchimento do Controle Visual (ListView) com os 50 últimos cadastros
            PreencherControlesDeTela();
        }

        void SelecionarLinha() 
        {
            if (listViewProdutos.SelectedItems.Count > 0) 
            {
                int idSelecionado = (int)listViewProdutos.SelectedItems[0].Tag;
                TelaIncluirProduto tela = new TelaIncluirProduto();
                tela._registro = idSelecionado;
                if (tela.ShowDialog() == DialogResult.OK)
                {
                    PreencherControlesDeTela();
                }
            }
        }

        public void PreencherControlesDeTela() 
        {
            //Método que prepara o controle visual antes de incluir os itens
            listViewProdutos.BeginUpdate();
            //Limpar completamente antes de preencher o controle com os novos itens
            listViewProdutos.Items.Clear();
            foreach (var produto in _listProdutos)
            {
                ListViewItem item = new ListViewItem();
                item.Tag = produto.ID;
                item.Text = produto.ID.ToString("00");
                item.SubItems.Add(produto.Descricao);
                item.SubItems.Add(produto.CodigoBarras);
                item.SubItems.Add(produto.PrecoVenda.ToString("c2"));
                listViewProdutos.Items.Add(item);
            }
            listViewProdutos.EndUpdate();
            //Mostrar os resultados na "label" inferior da janela de produtos
            lblResultado.Text = _listProdutos.Count.ToString("00")  + " produto(s) encontrado(s).";
        }

        private void listViewProdutos_DoubleClick(object sender, EventArgs e)
        {
            SelecionarLinha();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            //Verifica se há algum valor informado para ser localizado
            string busca = txtLocalizar.Text.Trim();
            if (!string.IsNullOrEmpty(busca)) 
            {
                _listProdutos = new DBProduto().LocalizarProdutos(busca);
                PreencherControlesDeTela();
            }        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtLocalizar.Text = string.Empty;
            _listProdutos = new DBProduto().ListarUltimos50Cadastros();
            PreencherControlesDeTela();
        }
    }
}
