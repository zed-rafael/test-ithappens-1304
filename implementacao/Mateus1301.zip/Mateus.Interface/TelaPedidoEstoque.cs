﻿using Mateus.Dominios;
using Mateus.Repositorio.Repositorios;
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;

namespace Mateus.Interface
{
    public partial class TelaPedidoEstoque : Mateus.Interface.TelaBaseListagem
    {

        public int _idPedido { get; set; }

        Carregamento loadItens = new Carregamento();
        Carregamento loadPedido = new Carregamento();
        Carregamento loadFinalizar = new Carregamento();
        public PedidoEstoque _pedidoEstoque { get; set; }
        public TelaPedidoEstoque()
        {
            InitializeComponent();
            loadItens._WORK =()=> 
            {
                _pedidoEstoque.ItensPedido = new DBItemPedido().ListaItemsDoPedido(_idPedido);
            };
            loadItens._COMPLETED = () => { PreencherGridItensPedido(); };

            loadPedido._WORK = () =>
            {
                _pedidoEstoque = new DBPedidoEstoque().VerPedido(_idPedido);
                _pedidoEstoque.ItensPedido = new DBItemPedido().ListaItemsDoPedido(_idPedido);
            };
            loadPedido._COMPLETED = () => { PreencherPedido(); PreencherGridItensPedido(); };

            loadFinalizar._WORK = () =>
            {
                new DBPedidoEstoque().FinalizarPedido(_pedidoEstoque.ID, _pedidoEstoque.TotalPedido,
                    _pedidoEstoque.FormaPagamento, _pedidoEstoque.ObservacaoEntrega);
            };
            loadFinalizar._COMPLETED = () => 
            {
                MessageBox.Show("Pedido finalizado com SUCESSO!", "Pedido finalizado", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                Close(); 
            };


        }

        void PreencherPedido()
        {
            txtCliente.Text = _pedidoEstoque.Cliente.Nome;
            txtFilial.Text = _pedidoEstoque.Filial.Descricao;
            txtStatus.Text = _pedidoEstoque.Status.ToString();
            if (_pedidoEstoque.Tipo == Enumerados.TipoPedidoEstoque.Entrada)
            {
                lblTipo.Text = "Entrada";
                lblTipo.BackColor = Color.DarkSeaGreen;
            }
            else
            {
                lblTipo.Text = "Saída";
                lblTipo.BackColor = Color.Firebrick;
            }
        }

        void PreencherGridItensPedido()
        {
            gridItensPedido.Items.Clear();
            foreach (var item in _pedidoEstoque.ItensPedido)
            {
                ListViewItem it = new ListViewItem();
                it.Tag = item;
                it.Text = item.ID.ToString("0000");
                it.SubItems.Add(item.Produto.Descricao);
                it.SubItems.Add(item.Produto.PrecoVenda.ToString("c2"));
                it.SubItems.Add(item.Quantidade.ToString("00"));
                it.SubItems.Add(item.ValorTotal.ToString("c2"));
                gridItensPedido.Items.Add(it);
            }
        }

        private void btnSelecionarFilial_Click(object sender, EventArgs e)
        {

        }

        private void TelaPedidoEstoque_Load(object sender, EventArgs e)
        {
            loadPedido.START();
        }

        private void btnIncluirItem_Click(object sender, EventArgs e)
        {
            TelaIncluirItemPedido tela = new TelaIncluirItemPedido();
            tela._filial = _pedidoEstoque.Filial.Descricao;
            tela._filialID = _pedidoEstoque.Filial.ID;
            tela._pedidoID = _pedidoEstoque.ID;
            tela._tipoPedido = _pedidoEstoque.Tipo;
            if (tela.ShowDialog() == System.Windows.Forms.DialogResult.OK) 
            {
                //Buscar em "paralelo" o itens do pedido no banco de dados 
                loadItens.START();
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (gridItensPedido.SelectedItems.Count > 0)
            {
                
            }
            else 
            {
                MessageBox.Show("Selecione um item para remover.", 
                    "Remover item", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnFinalizar_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
            {
                TelaFormaDePagamento tela = new TelaFormaDePagamento();
                if (tela.ShowDialog() == DialogResult.OK) 
                {
                    _pedidoEstoque.FormaPagamento = tela._formaPagamento;
                    _pedidoEstoque.ObservacaoEntrega = txtObservacoes.Text;
                    _pedidoEstoque.TotalPedido = _pedidoEstoque.ItensPedido.Sum(p => p.ValorTotal);
                    loadFinalizar.START();
                }
            }
            else 
            {
                MessageBox.Show("Erro no preenchimento dos campos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
