﻿using System.Windows.Forms;

namespace Mateus.Interface
{
    public partial class TelaBaseModal : Form
    {
        public TelaBaseModal()
        {
            InitializeComponent();
        }

        private void BtnFechar_Click(object sender, System.EventArgs e)
        {
            Close();
        }
    }
}
