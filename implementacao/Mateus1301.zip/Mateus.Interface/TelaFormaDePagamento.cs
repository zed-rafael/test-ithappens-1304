﻿using Mateus.Dominios;
using Mateus.Enumerados;
using Mateus.Repositorio.Repositorios;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Mateus.Interface
{
    public partial class TelaFormaDePagamento : Form
    {
        public FormaPagamento _formaPagamento { get; set; }
        public TelaFormaDePagamento()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, System.EventArgs e)
        {
            Close();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (rdbDinheiro.Checked) 
            {
                _formaPagamento = (FormaPagamento)1;
            }
                
            else if (rdbCartao.Checked)
                _formaPagamento = (FormaPagamento)2;
            else _formaPagamento = (FormaPagamento)3;
            DialogResult = DialogResult.OK;
        }
    }
}
