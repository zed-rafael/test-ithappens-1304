﻿using Mateus.Dominios;
using Mateus.Enumerados;
using Mateus.Repositorio.Repositorios;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Mateus.Interface
{
    public partial class TelaPedidosEstoque : TelaBaseListagem
    {
        Carregamento _loadListPedidos = new Carregamento();
        //Coleção (List) que irá armazenar os produtos para serem exibidos no grid
        List<PedidoEstoque> _listPedidos;
        PedidoEstoque _pedido = new PedidoEstoque();
        public TelaPedidosEstoque()
        {
            InitializeComponent();
            //Preenche o _listProdutos com os últimos 50 cadastros do banco de dados ao iniciar a exibição da tela

            _loadListPedidos._WORK = () =>
            {
                _listPedidos = new DBPedidoEstoque().ListarUltimos50Pedidos();
            };
            _loadListPedidos._COMPLETED = () => { PreencherControlesDeTela(); };
            _loadListPedidos._ERROR = () => MessageBox.Show("Erro ao consultar o banco de dados", "Erro na consulta", 
                MessageBoxButtons.OK, MessageBoxIcon.Warning);


        }

        private void btnInlcuir_Click(object sender, EventArgs e)
        {
            TelaNovoPedidoEstoque tela = new TelaNovoPedidoEstoque();
            if (tela.ShowDialog() == DialogResult.OK)
            {
                __Globais.AbrirJanelaNoDashboard(new TelaPedidoEstoque());
            }
        }

        //Chamado quando a tela é carregada
        private void TelaProdutos_Load(object sender, EventArgs e)
        {
            _loadListPedidos.START();
        }

        void SelecionarLinha()
        {
            if (gridPedidos.SelectedItems.Count > 0)
            {
                TelaPedidoEstoque tela = new TelaPedidoEstoque();
                tela._idPedido = (int)gridPedidos.SelectedItems[0].Tag;
                __Globais.AbrirJanelaNoDashboard(tela);
            }
        }
        public void PreencherControlesDeTela()
        {
            //Método que prepara o controle visual antes de incluir os itens
            gridPedidos.BeginUpdate();
            //Limpar completamente antes de preencher o controle com os novos itens
            gridPedidos.Items.Clear();
            foreach (var pedido in _listPedidos)
            {
                ListViewItem item = new ListViewItem();
                item.ImageIndex = (int)pedido.Tipo;
                item.Tag = pedido.ID;
                item.Text = pedido.ID.ToString("00");
                item.SubItems.Add(pedido.Cliente.Nome);
                item.SubItems.Add(pedido.Filial.Descricao);
                item.SubItems.Add(pedido.DataPedido.ToString("dd/MM/yyyy"));
                item.SubItems.Add(pedido.TotalPedido.ToString("c2"));
                item.SubItems.Add(((StatusPedido)pedido.Status).ToString());
                gridPedidos.Items.Add(item);
            }
            gridPedidos.EndUpdate();
            //Mostrar os resultados na "label" inferior da janela de produtos
            lblResultado.Text = _listPedidos.Count.ToString("00") + " pedido(s) encontrado(s).";
        }

        private void listViewProdutos_DoubleClick(object sender, EventArgs e)
        {
            SelecionarLinha();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            if (gridPedidos.SelectedItems.Count > 0)
            {
                int idPedido = (int)gridPedidos.SelectedItems[0].Tag;
                new DBPedidoEstoque().CancelarPedido(idPedido);
                _loadListPedidos.START();
            }
            else 
            {

            }
        }
    }
}
