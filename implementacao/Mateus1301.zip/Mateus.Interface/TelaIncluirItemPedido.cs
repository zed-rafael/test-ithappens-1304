﻿using Mateus.Dominios;
using Mateus.Enumerados;
using Mateus.Repositorio.Repositorios;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Mateus.Interface
{
    public partial class TelaIncluirItemPedido : Form
    {
        public string _filial { get; set; }
        public int _filialID { get; set; }
        public int _pedidoID { get; set; }
        public TipoPedidoEstoque _tipoPedido { get; set; }
        public Produto _produto { get; set; }
        public TelaIncluirItemPedido()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, System.EventArgs e)
        {
            Close();
        }

        private void btnOK_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (_produto != null) 
                {
                    int produtoID = _produto.ID;
                    int quantidadeItemPedido = Convert.ToInt32(txtQuantidade.Text);
                    decimal valorTotal = Convert.ToDecimal(quantidadeItemPedido * _produto.PrecoVenda);
                    new DBItemPedido().AdicionarItemPedido(_filialID, _pedidoID, produtoID,
                        quantidadeItemPedido, valorTotal, Enumerados.StatusItemPedido.Ativo, _tipoPedido);
                    DialogResult = DialogResult.OK;
                 }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSelecionarFilial_Click(object sender, System.EventArgs e)
        {
            TelaSelecionarProduto tela = new TelaSelecionarProduto();
            tela._Itens = new DBProduto().ListaBasicaProdutos();
            tela._TituloJanela = "Selecionar filial";
            if (tela.ShowDialog() == DialogResult.OK)
            {
                _produto = tela._itemSelecionado;
                _produto.PrecoVenda = tela._itemSelecionado.PrecoVenda;
                txtProduto.Text = _produto.Descricao;
                txtProduto.Tag = _produto.ID;
                lblPrecoVenda.Text = _produto.PrecoVenda.ToString("c2");
            }
        }

        private void TelaIncluirItemPedido_Load(object sender, EventArgs e)
        {
            lblFilial.Text = _filial;
        }
    }
}
