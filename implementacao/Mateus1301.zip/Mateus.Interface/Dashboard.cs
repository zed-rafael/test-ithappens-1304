﻿using System.Windows.Forms;

namespace Mateus.Interface
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void btnProdutos_Click(object sender, System.EventArgs e)
        {
            __Globais.AbrirJanelaNoDashboard(new TelaProdutos());
        }

        private void btnMenuPedidos_Click(object sender, System.EventArgs e)
        {
            __Globais.AbrirJanelaNoDashboard(new TelaPedidosEstoque());
        }

        private void btnSair_Click(object sender, System.EventArgs e)
        {
            Application.Exit();
        }

        private void Dashboard_Load(object sender, System.EventArgs e)
        {
            __Globais._Usuario = new Dominios.Usuario() { ID = 1, Nome = "José da Silva" };
            __Globais.AbrirJanelaNoDashboard(new TelaPedidosEstoque());
        }
    }
}
