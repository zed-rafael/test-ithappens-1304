﻿using Mateus.Dominios;
using Mateus.Repositorio.Repositorios;
using System;
using System.Windows.Forms;

namespace Mateus.Interface
{
    public partial class TelaIncluirProduto : TelaBaseModal
    {
        public int _registro { get; set; }
        public TelaIncluirProduto()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void TelaIncluirProduto_Load(object sender, EventArgs e)
        {
            if (_registro > 0)
            {
                PreencherControlesDeTela();
            }
        }

        public void PreencherControlesDeTela() 
        {
            Produto produto = new DBProduto().VerProduto(_registro);
            txtCodigoBarras.Text = produto.CodigoBarras;
            txtDescricao.Text = produto.Descricao;
            txtPrecoVenda.Text = produto.PrecoVenda.ToString().Replace('.', ',');
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            try
            {
                Produto produto = new Produto(_registro, txtDescricao.Text.Trim(), txtCodigoBarras.Text, txtPrecoVenda.Text);
                if (produto.Erro.Length == 0)
                {
                    //Salvar o objeto produto no repositório
                    if (_registro == 0)
                        new DBProduto().InserirProduto(produto);
                    else
                        new DBProduto().AtualizarProduto(produto);
                    //Mensagem de êxito para o usuário 
                    MessageBox.Show("O produto foi cadastrado com sucesso!", "Concluído", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Essa linha permite fechar a janela e enviar ao sistema operacional uma mensagem de OK
                    DialogResult = DialogResult.OK;
                }
                else
                {
                    MessageBox.Show(produto.Erro);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro");
            }
        }
    }
}
