﻿namespace Mateus
{
    public class Validacoes
    {

    }
}
