﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mateus.Dominios
{
    /// <summary>
    /// Classe de representação do domínio Estoque
    /// </summary>
    public class Estoque
    {
        public int ProdutoID { get; set; }
        public int Quantidade { get; set; }
        public int FilialID { get; set; }
    }
}
