﻿using Mateus.Enumerados;
using System;

namespace Mateus.Dominios
{
    public class Produto
    {
        public string Erro { get; set; }
        public int ID { get; set; }
        public string Descricao { get; set; }
        public string CodigoBarras { get; set; }
        public decimal PrecoVenda { get; set; }

        public Produto()
        {

        }

        public Produto(int id, string descricao, string codigoBarras, string precoVenda)
        {
            ID = id;
            decimal precoVendaOut;
            Erro = string.Empty;
            if (descricao.Length < 3 || descricao.Length > 50)
            {
                Erro += "Descrição do produto inválida (entre 3 e 50 caracteres)" + Environment.NewLine;
            }
            else
            {
                Descricao = descricao; 
            }
            if (codigoBarras.Length < 5 || codigoBarras.Length > 20)
            {
                Erro += "Código de barras inválido (entre 5 e 20 caracteres)" + Environment.NewLine; ;
            }
            else 
            {
                CodigoBarras = codigoBarras;
            }
            if (!decimal.TryParse(precoVenda, out precoVendaOut))
            {
                Erro += "Preço de venda inválido." + Environment.NewLine; ;
            }
            else 
            {
                PrecoVenda = precoVendaOut;
            }
        }

    }
}
