﻿using Mateus.Enumerados;
using System;
using System.Collections.Generic;

namespace Mateus.Dominios
{
    /// <summary>
    /// Classe de representação do domínio PedidoEstoque
    /// Irá ser composta pela classe CLIENTE e Produto
    /// </summary>
    public class PedidoEstoque
    {
        public PedidoEstoque()
        {
            Cliente = new Cliente();
            Filial = new Filial();
            ItensPedido = new List<ItemPedido>();
        }
        public int ID { get; set; }

        public Cliente Cliente { get; set; }
        public Filial Filial { get; set; }
        public Usuario Usuario { get; set; }
        public DateTime DataPedido { get; set; }

        public decimal TotalPedido { get; set; }

        public FormaPagamento FormaPagamento { get; set; }

        public TipoPedidoEstoque Tipo { get; set; }

        public StatusPedido Status { get; set; }

        public List<ItemPedido> ItensPedido { get; set; }

        public string ObservacaoEntrega { get; set; }

    }
}
