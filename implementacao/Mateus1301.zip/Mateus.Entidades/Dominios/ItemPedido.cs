﻿using Mateus.Enumerados;
using System;

namespace Mateus.Dominios
{
    public class ItemPedido
    {
        public ItemPedido()
        {
            Produto = new Produto();
        }
        public int ID { get; set; }

        public int PedidoEstoqueID { get; set; }

        public Produto Produto { get; set; }

        public int Quantidade { get; set; }

        public StatusItemPedido Status { get; set; }

        public decimal ValorTotal { get; set; }

        //Comportamento da classe
        #region Métodos

        #endregion
    }
}
