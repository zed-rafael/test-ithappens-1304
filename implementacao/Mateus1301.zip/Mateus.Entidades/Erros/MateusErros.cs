﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mateus.Erros
{
    /// <summary>
    /// Classe base para a personalização de erros de acordo com as especificações internas do MATEUS
    /// </summary>
    public class MateusErros : Exception
    {
        public MateusErros()
        {
        }

        public MateusErros(string message)
            : base(message)
        {
        }

        public MateusErros(string message, Exception e)
            : base(message, e)
        {
        }
    }
}
