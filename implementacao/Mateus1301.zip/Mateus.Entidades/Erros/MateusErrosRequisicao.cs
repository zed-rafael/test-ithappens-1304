﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mateus.Erros
{
    public class MateusErrosRequisicao : MateusErros
    {
        public int HTTPStatusCode { get; protected set; }
        
        public MateusErrosRequisicao(string message)
            : base(message)
        {
        }

        public MateusErrosRequisicao(int httpStatusCode, string responseBody)
            : base($"Erro na requisição (HTTP Code {httpStatusCode}): {responseBody}")
        {
            HTTPStatusCode = httpStatusCode;
        }
    }
}
