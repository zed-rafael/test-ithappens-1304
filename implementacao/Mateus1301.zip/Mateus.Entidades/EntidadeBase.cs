﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mateus
{
    /// <summary>
    /// Classe base responsável por permitir a herança de métodos básicos (conversão de objetos em JSON/XML...)
    /// Classes que precisarem de conserção deverão herdas essa classe
    /// </summary>
    class EntidadeBase
    {
        
    }
}
