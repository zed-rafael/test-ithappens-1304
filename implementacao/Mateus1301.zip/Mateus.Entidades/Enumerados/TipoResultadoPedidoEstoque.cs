﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mateus.Enumerados
{
    public enum TipoResultadoPedidoEstoque
    {
        ProdutoNaoCadastrado = 0,
        ProdutoAdicionadoNoEstoque = 1,
        ProdutoRetiradoDoEstoque = 2,
        EstoqueAtualizado = 3,
        EstoqueInsuficiente = 4,
        ProdutoCadastrado = 5,
        ErroAoTentarEfetuarPedido = 6
    }
}
