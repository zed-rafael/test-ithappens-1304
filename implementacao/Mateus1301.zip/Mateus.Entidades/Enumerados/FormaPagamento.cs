﻿namespace Mateus.Enumerados
{
    /// <summary>
    /// Enumerador da representação de todas as formas de pagamento disponíveis
    /// </summary>
    public enum FormaPagamento
    {
        Dinheiro = 1,
        Cartao = 2,
        Boleto = 3,
    }
}
