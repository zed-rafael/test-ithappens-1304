﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mateus.Enumerados
{
    public enum StatusItemPedido
    {
        Ativo = 1,
        Cancelado = 2,
        Processado,
    }
}
