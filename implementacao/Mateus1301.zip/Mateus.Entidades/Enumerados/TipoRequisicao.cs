﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mateus.Enumerados
{
    /// <summary>
    /// Enumerador que especifica os tipos de consultas via API
    /// </summary>
    public enum TipoRequisicao
    {
        VerProduto,
        VerCliente,
        VerPedido,
        ListarProtudos,
        ListarClientes,
        ListarProdutosFilial,
    }
}
