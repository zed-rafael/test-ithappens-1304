﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mateus.Enumerados
{
    public enum StatusPedido
    {
        EmAndamento = 0,
        Finalizado = 1,
        Cancelado = 2,
    }
}
